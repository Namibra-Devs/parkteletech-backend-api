<?php $__env->startComponent('mail::message'); ?>
Hello Employee,

<?php echo e($body); ?>


<?php $__env->startComponent('mail::button', ['url' => "sammple url"]); ?>
View Order
<?php echo $__env->renderComponent(); ?>

Regards,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Dell\Desktop\parkteletech-api\parkteletech-api\resources\views/emails/default.blade.php ENDPATH**/ ?>