[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\Dell\Desktop\parkteletech-api\parkteletech-api\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>